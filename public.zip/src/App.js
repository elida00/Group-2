
import './App.css';
import {FuterPage} from './components/Futer'

export const App=()=> {
  return (
    <div className="App">
      <FuterPage/>
    </div>
  );
}


